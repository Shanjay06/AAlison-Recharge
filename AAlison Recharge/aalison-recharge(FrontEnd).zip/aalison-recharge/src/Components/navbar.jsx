import { Link } from 'react-router-dom'
import { useState } from 'react'
import { useTheme } from '../App'

const Navbar = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const theme = useTheme()

  const handleLogout = () => {
    setIsLoggedIn(false)
    alert('Logged out successfully!')
  }

  return (
    <nav style={{
      background: theme.colors.cardBg,
      boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
      padding: '12px 0',
      position: 'sticky',
      top: 0,
      zIndex: 1000,
      transition: 'all 0.3s ease'
    }}>
      <div style={{maxWidth: '1200px', margin: '0 auto', padding: '0 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
        <Link to="/" style={{
          fontSize: '28px',
          fontWeight: '700',
          color: '#e60012',
          textDecoration: 'none',
          letterSpacing: '-0.5px'
        }}>
          Aalison
        </Link>
        <div style={{display: 'flex', gap: '40px', alignItems: 'center'}}>
          <Link to="/" style={{color: theme.colors.text, fontWeight: '500', textDecoration: 'none', fontSize: '16px', transition: 'color 0.3s'}}>Home</Link>
          <Link to="/plans" style={{color: theme.colors.text, fontWeight: '500', textDecoration: 'none', fontSize: '16px', transition: 'color 0.3s'}}>Plans</Link>
          <Link to="/history" style={{color: theme.colors.text, fontWeight: '500', textDecoration: 'none', fontSize: '16px', transition: 'color 0.3s'}}>History</Link>
          <Link to="/profile" style={{color: theme.colors.text, fontWeight: '500', textDecoration: 'none', fontSize: '16px', transition: 'color 0.3s'}}>Profile</Link>
          
          <button
            onClick={theme.toggleTheme}
            style={{
              background: 'none',
              border: `1px solid ${theme.colors.border}`,
              borderRadius: '20px',
              padding: '8px 12px',
              cursor: 'pointer',
              color: theme.colors.text,
              fontSize: '14px',
              transition: 'all 0.3s ease'
            }}
          >
            {theme.isDarkMode ? 'Light' : 'Dark'}
          </button>
          
          {isLoggedIn ? (
            <button
              onClick={handleLogout}
              style={{
                background: '#333',
                color: 'white',
                border: 'none',
                padding: '10px 20px',
                borderRadius: '25px',
                fontSize: '14px',
                fontWeight: '600',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                boxShadow: '0 4px 15px rgba(51, 51, 51, 0.3)'
              }}
              onMouseEnter={(e) => {
                e.target.style.background = '#000'
                e.target.style.boxShadow = '0 0 20px rgba(0, 0, 0, 0.8)'
                e.target.style.transform = 'translateY(-1px)'
              }}
              onMouseLeave={(e) => {
                e.target.style.background = '#333'
                e.target.style.boxShadow = '0 4px 15px rgba(51, 51, 51, 0.3)'
                e.target.style.transform = 'translateY(0)'
              }}
            >
              Logout
            </button>
          ) : (
            <Link 
              to="/login" 
              onClick={() => setIsLoggedIn(true)}
              style={{
                background: 'linear-gradient(135deg, #e60012 0%, #ff6600 100%)',
                color: 'white',
                padding: '10px 20px',
                borderRadius: '25px',
                textDecoration: 'none',
                fontSize: '14px',
                fontWeight: '600',
                transition: 'all 0.3s ease',
                boxShadow: '0 4px 15px rgba(230, 0, 18, 0.3)'
              }}
            >
              Login
            </Link>
          )}
        </div>
      </div>
    </nav>
  )
}

export default Navbar